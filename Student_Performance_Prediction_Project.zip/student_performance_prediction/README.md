# Student Performance Prediction System

A beginner-friendly Python machine learning project that predicts a student's final score using:
- Study hours
- Attendance percentage
- Previous academic score

## Technologies
Python, Pandas, Scikit-learn

## Workflow
1. Load CSV data
2. Select features and target
3. Split data into training and testing sets
4. Standardize features
5. Train a Linear Regression model
6. Evaluate using MAE, MSE, and R² score
7. Predict the score for a new student

## Run
```bash
pip install -r requirements.txt
python student_performance_prediction.py
```

## Resume description
Developed a Python-based machine learning system to predict student performance using study hours, attendance, and previous academic scores. Performed data preprocessing, feature scaling, model training, and evaluation using MAE, MSE, and R² metrics.
